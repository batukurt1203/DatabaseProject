﻿
INSERT INTO EmployeeProductAssignment (AssignmentID, Employee_PersonID, ProductID, RoleOnProduct)
VALUES
    (1, 1, 1, 'Senior Developer'), -- 101 ID'li çalışan IRONIC projesinde Kıdemli Geliştirici
    (2, 2, 1, 'QA Specialist'),    -- 102 ID'li çalışan IRONIC projesinde Test Uzmanı
    (3, 3, 2, 'Project Manager'),  -- 103 ID'li çalışan ISGPRO projesinde Proje Yöneticisi
    (4, 1, 2, 'Consultant');       -- 101 ID'li çalışan aynı zamanda ISGPRO'da Danışman