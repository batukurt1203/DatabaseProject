use AKADEMEDYA

EXECUTE dbo.pro_CreateEmployee 'Emre Karaca', '2021-02-05', 'emrekaraca@gmail.com', '1234', NULL

EXECUTE dbo.pro_CreateEmployee 'Kadir Demir', '2024-03-10', 'kadirdemir@hotmail.com', '1234', 'emrekaraca@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Selim Aksoy', '2023-07-16', 'selimaksoy@gmail.com', '1234', 'emrekaraca@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Leyla Çelik', '2022-05-20', 'leylacelik@gmail.com', '1234', 'emrekaraca@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Aysel Yılmaz', '2023-09-12', 'ayselyilmaz@gmail.com', '1234', 'emrekaraca@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Berkcan Gül', '2022-11-03', 'berkcangul@gmail.com', '1234', 'emrekaraca@gmail.com'


EXECUTE dbo.pro_CreateEmployee 'Yusuf Demirtaş', '2022-01-25', 'yusufdemirtas@gmail.com', '1234', 'kadirdemir@hotmail.com'
EXECUTE dbo.pro_CreateEmployee 'Seda Çetin', '2023-08-04', 'sedacetin@gmail.com', '1234', 'kadirdemir@hotmail.com'
EXECUTE dbo.pro_CreateEmployee 'Berk Yılmaz', '2023-06-01', 'berkyilmaz@gmail.com', '1234', 'kadirdemir@hotmail.com'
EXECUTE dbo.pro_CreateEmployee 'Alev Uçar', '2024-03-23', 'alevucar@gmail.com', '1234', 'kadirdemir@hotmail.com'
EXECUTE dbo.pro_CreateEmployee 'Merve Demirtaş', '2023-02-05', 'mervedemirtas@gmail.com', '1234', 'kadirdemir@hotmail.com'
EXECUTE dbo.pro_CreateEmployee 'Orhan Şahin', '2022-12-13', 'orhansahin@gmail.com', '1234', 'kadirdemir@hotmail.com'
EXECUTE dbo.pro_CreateEmployee 'Murat Tuncer', '2023-04-09', 'murattuncer@gmail.com', '1234', 'kadirdemir@hotmail.com'

EXECUTE dbo.pro_CreateEmployee 'Mustafa Aydın', '2024-01-18', 'mustafaaydin@gmail.com', '1234', 'selimaksoy@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Derya Kaya', '2022-09-01', 'deryakaya@gmail.com', '1234', 'selimaksoy@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Fikret Kara', '2023-04-30', 'fikretkara@gmail.com', '1234', 'selimaksoy@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Pelin Özdemir', '2022-07-11', 'pelinozdemir@gmail.com', '1234', 'selimaksoy@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Onur Akpınar', '2022-02-17', 'onurakpinar@gmail.com', '1234', 'selimaksoy@gmail.com'


EXECUTE dbo.pro_CreateEmployee 'Serdar Yıldırım', '2023-03-23', 'serdaryildirim@gmail.com', '1234', 'leylacelik@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Sibel Demirci', '2024-01-10', 'sibeldemirci@gmail.com', '1234', 'leylacelik@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Ece Aydın', '2023-12-02', 'eceaydin@gmail.com', '1234', 'leylacelik@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Ahmet Öztürk', '2022-04-08', 'ahmetozturk@gmail.com', '1234', 'leylacelik@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Sena Güler', '2023-06-26', 'senaguler@gmail.com', '1234', 'leylacelik@gmail.com'


EXECUTE dbo.pro_CreateEmployee 'Esra Arslan', '2023-05-16', 'esraarslan@gmail.com', '1234', 'ayselyilmaz@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Cemre Bayram', '2022-12-07', 'cemrebayram@gmail.com', '1234', 'ayselyilmaz@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Murat Baykal', '2022-10-19', 'muratbaykal@gmail.com', '1234', 'ayselyilmaz@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Burak Akın', '2022-08-03', 'burakakin@gmail.com', '1234', 'ayselyilmaz@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Hüseyin Tok', '2023-01-11', 'huseyintok@gmail.com', '1234', 'ayselyilmaz@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Seda Arık', '2022-08-27', 'sedarik@gmail.com', '1234', 'ayselyilmaz@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Selman Güngör', '2023-10-15', 'selmangungor@gmail.com', '1234', 'ayselyilmaz@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Hülya Aydın', '2022-11-02', 'hulyaydin@gmail.com', '1234', 'ayselyilmaz@gmail.com'


EXECUTE dbo.pro_CreateEmployee 'Nisan Karabulut', '2022-03-14', 'nisankarabulut@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Tugçe Özkan', '2024-02-20', 'tugceozkan@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Gökhan Demirtaş', '2023-11-08', 'gokhandemirtas@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Büşra Özcan', '2024-01-07', 'busraozcan@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Murat Tokgöz', '2022-06-09', 'murattokgoz@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Ömer Çakır', '2022-01-30', 'omercakir@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Mehmet Yılmaz', '2023-03-17', 'mehmetyilmaz@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Emine Kılıç', '2023-07-28', 'eminekilic@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Nihat Güngör', '2022-05-03', 'nihatgungor@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Serkan Gökalp', '2023-12-17', 'serkangokalp@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Berkay Çolak', '2024-02-02', 'berkaycolak@gmail.com', '1234', 'berkcangul@gmail.com'
EXECUTE dbo.pro_CreateEmployee 'Yusuf Çelik', '2023-10-22', 'yusufcelik@gmail.com', '1234', 'berkcangul@gmail.com'







